import React, { useState } from 'react';
import { StyleSheet, Text, View, Image, Button, TouchableOpacity } from 'react-native';

export default function App() {
  const [fortune, setFortune] = useState('');
  const [isCookieBroken, setIsCookieBroken] = useState(false);

  const fortunes = [
    "A sorte favorece os corajosos!",
    "Você terá um dia incrível hoje.",
    "Novas oportunidades estão a caminho.",
    "Confie em seu instinto.",
    "Algo grande está por vir!",
    "A felicidade está ao virar da esquina.",
    "Grandes coisas acontecem a quem espera.",
    "Suas habilidades irão impressionar os outros em breve."
  ];
  const getRandomFortune = () => {
    const randomIndex = Math.floor(Math.random() * fortunes.length);
    setFortune(fortunes[randomIndex]);
    setIsCookieBroken(true);
  };
  const resetCookie = () => {
    setFortune('');
    setIsCookieBroken(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Fortune Cookie App</Text>
      <Image 
        source={isCookieBroken ? require('./assets/FortuneCookieOpen.png') : require('./assets/FortuneCookieClosed.png')}
        style={styles.cookieImage}
      />
      {fortune ? <Text style={styles.fortuneText}>{fortune}</Text> : null}
      <TouchableOpacity 
        style={styles.button} 
        onPress={isCookieBroken ? resetCookie : getRandomFortune}
      >
        <Text style={styles.buttonText}>
          {isCookieBroken ? 'Abrir Novo Biscoito' : 'Quebrar o Biscoito'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  cookieImage: {
    width: '80%',
    maxWidth: 300,
    height: 'auto',
  },
  fortuneText: {
    marginVertical: 20,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  button: {
    marginTop: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#4CAF50',
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});
