import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, Image, Button, ActivityIndicator } from 'react-native';
import axios from 'axios';

const LOCAL_QUOTES = false; // Trocar para true se usar arquivo local JSON

const QuotesApp = () => {
  const [quote, setQuote] = useState('');
  const [author, setAuthor] = useState('');
  const [image, setImage] = useState('');
  const [loading, setLoading] = useState(true);

  // Função para buscar citação aleatória da API Quotable
  const fetchQuoteFromAPI = async () => {
    setLoading(true);
    try {
      const response = await axios.get('https://api.quotable.io/random');
      setQuote(response.data.content);
      setAuthor(response.data.author);
      // Usar uma API de avatares como Adorable para imagens
      setImage(`https://api.adorable.io/avatars/285/${response.data.author}.png`);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // Função para buscar citação de arquivo JSON local
  const fetchQuoteFromLocal = () => {
    setLoading(true);
    try {
      const quotes = require('./assets/quotes.json');
      const randomIndex = Math.floor(Math.random() * quotes.length);
      setQuote(quotes[randomIndex].quote);
      setAuthor(quotes[randomIndex].author);
      setImage(quotes[randomIndex].image);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // Função para buscar nova citação
  const fetchNewQuote = () => {
    if (LOCAL_QUOTES) {
      fetchQuoteFromLocal();
    } else {
      fetchQuoteFromAPI();
    }
  };

  // Efeito para buscar citação ao inicializar o app
  useEffect(() => {
    fetchNewQuote();
  }, []);

  return (
    <View style={styles.container}>
      {loading ? (
        <ActivityIndicator size="large" color="#0000ff" />
      ) : (
        <>
          <Text style={styles.quote}>"{quote}"</Text>
          <Text style={styles.author}>- {author}</Text>
          <Image source={{ uri: image }} style={styles.image} />
          <Button title="Nova Citação" onPress={fetchNewQuote} />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  quote: {
    fontSize: 18,S
    fontStyle: 'italic',
    textAlign: 'center',
    marginBottom: 10,
  },
  author: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
});

export default QuotesApp;
